
Rieles en Riesgo — Visualizaciones (Paloma Riquelme)
==================================================

Contenido del paquete:
- visualizaciones/
  - accidentes_franja_consecuencia_titulado.png  (con fondo beige y título)
  - accidentes_franja_consecuencia_limpio.png    (sin fondo, para afiche)
  - evolucion_anual_consecuencia_titulado.png
  - evolucion_anual_consecuencia_limpio.png
  - tasa_fallecidos_franja_titulado.png
  - tasa_fallecidos_franja_limpio.png
  - resumen_por_franja_consecuencia.csv
  - evolucion_anual_consecuencia.csv
  - tasa_fallecimientos_franja.csv

- base_datos/
  - Paloma_database_original.csv  (copia del CSV original subido)
  - Paloma_database_limpia.csv    (versión tidy/long utilizada para gráficos)

Paleta de colores (Rieles en Riesgo):
- Azul acero: #1D3557
- Beige ferroviario: #EAE7E0
- Óxido: #E07A5F
- Verde oliva: #4A5A37
- Blanco: #FFFFFF

Crédito:
Fuente: Elaboración propia — Proyecto “Rieles en Riesgo” (2019–2024)

Notas técnicas:
- Los gráficos PNG etiquetados son de dimensión 1920x1080 (apropiados para afiche web).
- Las versiones 'limpias' tienen fondo transparente para facilitar su integración en maquetas.
- También se incluyen CSVs resumen y la base de datos 'lnga' (tidy) usada para generar las visualizaciones.
- Si necesitas las versiones interactivas en Altair (.html), incluyo en la carpeta un archivo 'ALTair_snippets.txt' con el código Altair listo para ejecutar en un entorno que tenga Altair instalado.
